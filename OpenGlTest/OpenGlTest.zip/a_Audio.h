#pragma once
#include "BudgieApp.h"
class a_Audio
{
public:

	void Play();

	a_Audio();
	~a_Audio();
};

